package com.codingdojo.contadorweb.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import jakarta.servlet.http.HttpSession;

@Controller
public class MainControllerContadorWeb {

	// METODOS CLASE
	private void setContadorSesion(HttpSession sesion, int numeroVeces) {
		sesion.setAttribute("contador", numeroVeces);
	}

	
	private int getContadorSesion(HttpSession sesion) {
		Object valorSesion = sesion.getAttribute("contador");
		if(valorSesion == null) {
			setContadorSesion(sesion, 0);
			valorSesion = sesion.getAttribute("contador");
		}
		return  (int) valorSesion;
	}

	@GetMapping("/")
	public String index(HttpSession sesion, HttpSession ses) {
		System.out.println(sesion.getAttribute("contador") + " Que es null???");
		int conteoActual = getContadorSesion(sesion);
		setContadorSesion(ses, 50);
		System.out.println(sesion.getAttribute("contador")+ " Ques es sesion en este punto de ejecucion");
		setContadorSesion(sesion, conteoActual+1);

		return "index.jsp";

	}
	
	@GetMapping("/contador")
	public String contador(HttpSession sesion, Model modelo) {
		modelo.addAttribute("contadorxdd",getContadorSesion(sesion));
		return "contadorweb.jsp" ;
	}
	
//	@GetMapping("/contador2")
//	public String contador2(HttpSession sesion, Model modelo) {
//		modelo.addAttribute("contador2",getContadorSesion(sesion));
//		int conteoActual2 = getContadorSesion(sesion);
//		setContadorSesion(sesion, conteoActual2+5);
//		return "contadorweb.jsp" ;
//	}
	
	
	
	@GetMapping("/reset")  //HARA QUE NUESTROS CONTADORES VUALVAN A 0... O NULL EN su respectivo caso
	public String reset(HttpSession reiniciar) {
		reiniciar.invalidate();
		return "redirect:/contador";
	}

}
