package com.codingdojo.contadorweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Z3contadorwebApplication {

	public static void main(String[] args) {
		SpringApplication.run(Z3contadorwebApplication.class, args);
	}

}
