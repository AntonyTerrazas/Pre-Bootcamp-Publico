package com.codingdojo.contadorweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Z3contadorwebApplicationTests {

	@Test
	void contextLoads() {
	}

}
