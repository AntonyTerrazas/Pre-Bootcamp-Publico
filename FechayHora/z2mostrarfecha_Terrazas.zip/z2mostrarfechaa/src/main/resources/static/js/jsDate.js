document.addEventListener("DOMContentLoaded", function () {
    // Mostrar la ventana emergente al cargar la página
    setTimeout(function () {
        var respuesta = confirm("¿Te gusta la fecha?¿Es esta la plantilla de fecha?");
        if (respuesta) {
            alert("¡Me alegra que te guste y sea la plantilla!");
        } else {
            alert("Oh, ¡qué lástima!");
        }
    }, 1000); // Espera 1 segundo antes de mostrar la ventana emergente
});

