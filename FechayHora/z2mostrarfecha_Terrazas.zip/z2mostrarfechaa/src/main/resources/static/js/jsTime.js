
//var respuesta = confirm("¿Esta es la plantilla de tiempo?");
//if (respuesta) {
//    alert("Si.");
//} else {
//    alert("NO");
//}
