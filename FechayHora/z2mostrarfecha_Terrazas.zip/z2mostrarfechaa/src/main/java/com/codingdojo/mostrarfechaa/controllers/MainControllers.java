package com.codingdojo.mostrarfechaa.controllers;

import java.time.LocalDate;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MainControllers {
	
	
	@RequestMapping("")
	public String Inicio() {
		return "index.jsp";
	}
	
	@GetMapping("/date")
	public String Fecha(Model model) {
		LocalDate fecha = LocalDate.now();
		model.addAttribute("fechaxd",fecha);
		
		return "date.jsp";
	}
	
	@GetMapping("/time")
	public String Tiempo(Model model) {
		LocalDate tiempo = LocalDate.now();
		model.addAttribute("tiempoxd",tiempo);
		return "time.jsp";
	}
	
	

}
