package com.codingdojo.mostrarfechaa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Z2mostrarfechaaApplication {

	public static void main(String[] args) {
		SpringApplication.run(Z2mostrarfechaaApplication.class, args);
	}

}
