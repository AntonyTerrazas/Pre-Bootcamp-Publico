package com.tony.guardiazoo2.main;

import com.tony.guardiazoo2.clases.Murcielago;

public class TestMurcielago {

	public static void main(String[] args) {

		Murcielago bart = new Murcielago();
		System.out.println(bart.atacarCiudad());
		System.out.println(bart.atacarCiudad());
		System.out.println(bart.atacarCiudad());
		System.out.println(bart.comerHumanos());
		System.out.println(bart.comerHumanos());
		System.out.println(bart.volar());
		System.out.println(bart.volar());
		
		System.out.println("Lamentablemente el murcialgo se quedó sin Energias");
		
		
	}

}
