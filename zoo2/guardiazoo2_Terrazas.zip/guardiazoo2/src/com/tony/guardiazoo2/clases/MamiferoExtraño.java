package com.tony.guardiazoo2.clases;

public class MamiferoExtraño {

	protected int nivelEnergia = 300;

	
	
	//GET y SET:
	public int getNivelEnergia() {
		return nivelEnergia;
	}

	public void setNivelEnergia(int nivelEnergia) {
		this.nivelEnergia = nivelEnergia;
	}
	  //MOSTRAR ENERGIA
	public int mostrarEnergia() {
		System.out.println("Su energia es: " + nivelEnergia);
		return nivelEnergia;
		
	}
	
	
}
