package com.tony.guardiazoo2.clases;

public class Murcielago extends MamiferoExtraño{

	public String volar() {
		setNivelEnergia(getNivelEnergia() - 50 );
		return "El murcielago se puso a volar y su energia disminuyo a : " + nivelEnergia;
	}
	public String comerHumanos() {
		setNivelEnergia(getNivelEnergia() +25 );
		return "El murcielago empezo A COMER HUMANOS!! Su energia aumento a : " + nivelEnergia;
	}
	
	public String atacarCiudad() {
		setNivelEnergia(getNivelEnergia() - 100 );
		return "El murcielago está atacando tu ciudad cercana y esta el LLAMAS!! Su nivel de energia se ha reducido a : " + nivelEnergia;
	}


}