package com.tony.solopruebas.clases;

public class Prueba {
    private double operacion1;
    private double operacion2;
    private String operacion;
    private double resultado;

    public void setOperandOne(double operandOne) {
        this.operacion1 = operandOne;
    }

    public void setOperacion(String operation) {
        this.operacion = operation;
    }

    public void setOperacion2(double operand2) {
        this.operacion2 = operand2;
    }

    public void performOperation() {
        if (operacion.equals("+")) {
            resultado = operacion1 + operacion2;
        } else if (operacion.equals("-")) {
            resultado = operacion1 - operacion2;
        } else {
            System.out.println("Operación no válida");
        }
    }

    public double getResultado() {
        return resultado;
    }
    }
