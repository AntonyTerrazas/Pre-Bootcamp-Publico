package com.tony.solopruebas.main;

import com.tony.solopruebas.clases.Prueba;

public class testprueba {

	public static void main(String [] args){
		
		Prueba calculator = new Prueba();

        calculator.setOperandOne(10.5);
        calculator.setOperacion("+");
        calculator.setOperacion2(5.2);

        calculator.performOperation();
        double finalResultado = calculator.getResultado();

        System.out.println("El resultado es: " + finalResultado);

        
}
}
