package com.tony.countries;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Z13countriesApplicationTests {

	@Test
	void contextLoads() {
	}

}
