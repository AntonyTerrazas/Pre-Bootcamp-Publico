package com.tony.countries.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.tony.countries.repositories.CitiesRepo;
import com.tony.countries.repositories.CountriesRepo;

@Service
public class ApiService {

	
	//INYECCION
	private final CountriesRepo countriesRepo;
	private final CitiesRepo citiesRepo;
	public ApiService(CountriesRepo counRep, CitiesRepo citiRep) {
		this.countriesRepo = counRep;
		this.citiesRepo = citiRep;
	}

	public List<Object[]> primerPregunta(){
		return countriesRepo.hablanSloveno();
	}
	
	public List<Object[]> segundaPregunta(){
		return countriesRepo.ciudadesPorPais();
	}
	
	public List<Object[]> tercerPregunta(){
		return citiesRepo.ciudadesMexicoPoblacion();
	}
	
	public List<Object[]> cuartaPregunta(){
		return countriesRepo.porcentajePais();
	}
	
	public List<Object[]> quintaPregunta(){
		return countriesRepo.superficiePaisesPoblación();
	}
	
	public List<Object[]> sextaPregunta(){
		return countriesRepo.paisesPorMonarquiaSuperficieVida();
	}
	
	public List<Object[]> septimaPregunta(){
		return citiesRepo.ciudadesArgentinaBsAs();
	}
	
	public List<Object[]> octavaPregunta(){
		return countriesRepo.sumPaisesRegion();
	}
}
