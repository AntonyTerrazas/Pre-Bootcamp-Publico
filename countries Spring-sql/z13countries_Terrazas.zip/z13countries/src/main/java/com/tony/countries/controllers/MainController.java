package com.tony.countries.controllers;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.tony.countries.services.ApiService;

@Controller
public class MainController {

	private final ApiService apiService;
	public MainController(ApiService cSer) {
		this.apiService = cSer;
	}
	
	@GetMapping("/")
    public String uno(Model viewModel) {
        List<Object[]> table = apiService.primerPregunta();
        viewModel.addAttribute("primeraTabla", table);
        return "1.jsp";
    }
	
	@GetMapping("/2")
    public String dos(Model viewModel) {
        List<Object[]> table = apiService.segundaPregunta();
        viewModel.addAttribute("segundaTabla", table);
        return "2.jsp";
    }
	
	@GetMapping("/3")
    public String tres(Model viewModel) {
        List<Object[]> table = apiService.tercerPregunta();
        viewModel.addAttribute("tercerTabla", table);
        return "3.jsp";
    }
	
	@GetMapping("/4")
    public String cuatro(Model viewModel) {
        List<Object[]> table = apiService.cuartaPregunta();
        viewModel.addAttribute("cuartaTabla", table);
        return "4.jsp";
    }
	
	@GetMapping("/5")
    public String cinco(Model viewModel) {
        List<Object[]> table = apiService.quintaPregunta();
        viewModel.addAttribute("quintaTabla", table);
        return "5.jsp";
    }
	
	@GetMapping("/6")
    public String seis(Model viewModel) {
        List<Object[]> table = apiService.sextaPregunta();
        viewModel.addAttribute("sextaTabla", table);
        return "6.jsp";
    }
	
	@GetMapping("/7")
    public String siete(Model viewModel) {
        List<Object[]> table = apiService.septimaPregunta();
        viewModel.addAttribute("septimaTabla", table);
        return "7.jsp";
    }
	
	@GetMapping("/8")
    public String ocho(Model viewModel) {
        List<Object[]> table = apiService.octavaPregunta();
        viewModel.addAttribute("octavaTabla", table);
        return "8.jsp";
    }
	
}
