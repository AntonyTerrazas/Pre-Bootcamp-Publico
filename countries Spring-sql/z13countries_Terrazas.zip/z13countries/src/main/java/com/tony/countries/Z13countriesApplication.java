package com.tony.countries;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Z13countriesApplication {

	public static void main(String[] args) {
		SpringApplication.run(Z13countriesApplication.class, args);
	}

}
