package com.codingdojo.holahumano;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Z1holahumanoApplication {

	public static void main(String[] args) {
		SpringApplication.run(Z1holahumanoApplication.class, args);
	}

}
