package com.codingdojo.holahumano.controllers;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Controllers {

	@RequestMapping("")
	public String Humano() {
		return "<h1>HolaHumano</h1>" ;
	}
	
	@GetMapping("")
	public String Parametro(@RequestParam(name = "nombre", defaultValue = "Usuario")String nombre ) {
		return "Hola, " + nombre + "!!";
	}
	
	

	
}
