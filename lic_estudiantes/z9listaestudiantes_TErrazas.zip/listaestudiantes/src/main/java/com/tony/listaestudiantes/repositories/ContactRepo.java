package com.tony.listaestudiantes.repositories;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.tony.listaestudiantes.models.ContactModel;



@Repository
public interface ContactRepo extends CrudRepository<ContactModel, Long>{
	
	

}






