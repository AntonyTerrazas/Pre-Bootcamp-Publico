package com.tony.licencias.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tony.licencias.models.Licencia;
import com.tony.licencias.models.Persona;
import com.tony.licencias.repositories.LicenciaRepo;
import com.tony.licencias.repositories.PersonaRepo;

@Service
public class MainService {

	// INYECCION DEPENDENCIAS (conexion con REPOSITORY de c/u)
	@Autowired
	public LicenciaRepo LicenciaRepo;

	@Autowired
	public PersonaRepo personaRepo;

	// CREAR 1°METODO-->
	// METODO DEL SERVICIO DE CREAR USUARIO/persona
	public Persona crearPersona(Persona persona) {// se obtener el objeto de form que elvio el usuario, ESTA EN
													// MAINCONTROLLER aDDaTRIBUTE
		return personaRepo.save(persona);

	}

	public List<Persona> todasPersonas() {
		return personaRepo.findAll();
	}

	// SERVICIO PARA LICENCIA
	public Licencia crearLicencia(Licencia licencia) {// se obtener el objeto de form que elvio el usuario, ESTA EN
//		la siguiente linea ayuda con la creacion de numero de licencia
		licencia.setNumber(this.generarNumerLic());												// MAINCONTROLLER aDDaTRIBUTE
		return LicenciaRepo.save(licencia);

	}

	// CREAREMOS UN METODO QUE LLAMARA AL METODO DEL REPOSITORIO para saber las
	// personas sin licencia
	public List<Persona> obtenerPersonasSinLicencia() {
//		return personaRepo.findByLicenciaIdIsNull();
		return personaRepo.encontrarNoLic();

	}

	//Metodo para generar numero de licencia
		public int generarNumerLic() {
			Licencia lic = LicenciaRepo.findTopByOrderByNumberDesc();
			if(lic ==null) {
				return 1;
			}
			int numeroMayorLicencia = lic.getNumber();
			numeroMayorLicencia++;
			return numeroMayorLicencia;
			
		}
		 public Persona buscarPersonaPorId(Long id) {
		        Optional<Persona> optionalPersona = personaRepo.findById(id);
		        return optionalPersona.orElse(null);
		    }
	
}
