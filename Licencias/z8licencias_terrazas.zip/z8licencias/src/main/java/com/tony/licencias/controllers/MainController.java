package com.tony.licencias.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.tony.licencias.models.Licencia;
import com.tony.licencias.models.Persona;
import com.tony.licencias.services.MainService;

import jakarta.validation.Valid;

@Controller
public class MainController {
	
	//INYECCION DEPENDENCIAS (De Service)
	@Autowired
	public MainService mainService;

	
	@GetMapping("/")
	public String root(Model viewModel) {
		
		List<Persona> todosUsuarios = mainService.todasPersonas();
		viewModel.addAttribute("todos", todosUsuarios);
		return "index.jsp";
	}
	
	
	
	@GetMapping("/person/new")
	public String formularioPersona(@ModelAttribute("persona")Persona persona) {
		return "newperson.jsp";
	}
	@PostMapping("/person/new")
	public String crearPersona(@Valid @ModelAttribute("persona")Persona persona,
			BindingResult resultado) {
		//NECESITAMOS HACER LAS CONSULTAS(validaciones) ADECUADAS:
		if(resultado.hasErrors()) {
			return "newperson.jsp";
		}//caso contrario deberiamos llamar al SERVICE: que ahora no tiene nada...COMPLETAR:
		
		//UNA VEZ TERMINADO CON EL SERVICE (de crear usuario) recien retornamos ...
		mainService.crearPersona(persona);
		return "redirect:/";
	}
	
	
	
	@GetMapping("/licencias/new")
	public String crearLicencia(@ModelAttribute("licencia")Licencia licencia,Model viewModel) {
		//con el model estamos llamando al service y este a su vez al reposiroti para MOSTRAR la LISTA DE PERSONAS:
	
		//	List<Persona> todosUsuarios = mainService.todasPersonas(); //Una vez tenemos los usuarios llamamos a MODELO para agregar esta lista
		//viewmodel.addAttribute("personas",todosUsuarios); //con esto ya podemos iterar en "newlicencia.jsp" con el c:forEach (gracias al model model que usamos)
		viewModel.addAttribute("personas",mainService.obtenerPersonasSinLicencia());
		return "newlicencia.jsp";
	}
	@PostMapping("/licencias/new")
	public String crearLicencia(@Valid  @ModelAttribute("licencia")Licencia licencia,
			BindingResult resultado,Model viewModel) {
		
		if(resultado.hasErrors()) {
//			viewModel.addAttribute("personas",mainService.todasPersonas());  //Estos ervira para quitar error cuando se envia vacio ,no aparece los nombres.
			viewModel.addAttribute("personas",mainService.obtenerPersonasSinLicencia());
			return "newlicencia.jsp";
		}//caso contrario deberiamos llamar al SERVICE: que ahora no tiene nada...COMPLETAR:
		
		//UNA VEZ TERMINADO CON EL SERVICE (de crear usuario) recien retornamos ...
		mainService.crearLicencia(licencia);
		
		return "redirect:/";
		
	}
	//MOSTRRAR PERSONAS
	
	@GetMapping("/licencias/{id}")
	public String mostrarPersona(@PathVariable("id") Long id, Model viewModel) {
	    Persona personaBuscada = mainService.buscarPersonaPorId(id);
	    
	    if (personaBuscada != null) {
	        viewModel.addAttribute("personaBuscada", personaBuscada);
	    } else {
	        viewModel.addAttribute("mensajeError", "Persona no encontrada");
	    }
	    
	    return "showinfo.jsp";
	}
	
	
}
