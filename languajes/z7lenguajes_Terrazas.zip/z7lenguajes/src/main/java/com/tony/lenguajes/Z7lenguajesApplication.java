package com.tony.lenguajes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Z7lenguajesApplication {

	public static void main(String[] args) {
		SpringApplication.run(Z7lenguajesApplication.class, args);
	}

}
