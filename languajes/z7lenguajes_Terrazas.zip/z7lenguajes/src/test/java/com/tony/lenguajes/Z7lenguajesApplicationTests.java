package com.tony.lenguajes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Z7lenguajesApplicationTests {

	@Test
	void contextLoads() {
	}

}
