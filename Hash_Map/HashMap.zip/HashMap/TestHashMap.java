import java.util.Set;
import java.util.HashMap;

public class TestHashMap {

    public static void main(String[] args) {
        HashMapdemo manipulador = new HashMapdemo();
        HashMap<String, String> lista = manipulador.tracklist();
        Set<String> claves = lista.keySet(); 

        for (String key : claves) {
            System.out.println("Nombre cancion"+key);

            System.out.println("letra cancion"+lista.get(key));
        }
    }
}
