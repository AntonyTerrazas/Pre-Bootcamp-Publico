import java.util.HashMap;

public class HashMapdemo {
    public HashMap<String, String> tracklist() {
        HashMap<String, String> listaHash = new HashMap<String, String>();
        listaHash.put("PajaroCantor", "Caminamos por la cornisa.Cada vez que intentamamos Apagar el incendio, Tomandonos de las manos");
        listaHash.put("oncemil", "Ahogandome en palabras mudas,Con las manos duras de arañar la arena");
        listaHash.put("cienaños", "Ahora y cien años mas, Las cosa van a ser igual");
        listaHash.put("sinprincipio", "Como un eclipse sin final de Sol y Luna");

        return listaHash;
    }
}
