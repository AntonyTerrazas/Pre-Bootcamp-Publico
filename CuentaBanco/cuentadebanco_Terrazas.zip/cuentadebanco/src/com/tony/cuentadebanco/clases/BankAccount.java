package com.tony.cuentadebanco.clases;

import java.util.Random;

public class BankAccount {

	private String nroCuenta;
	private Double saldoCC; // Saldo Cuenta Corriente
	private Double saldoCA; // Saldo Cuenta Ahorro

	private static int nroCuentasCreadas;
	private static double dineroTotalEnCuentas;

	public BankAccount() {
		this.nroCuenta = generarNuemroCuenta();

		nroCuentasCreadas++;
	}

	// METODO 10 DIGITOS ALEATORIOS
	public String generarNuemroCuenta() {
		Random random = new Random();
		StringBuilder numeroCuentaBanco = new StringBuilder();

		for (int i = 0; i < 10; i++) {
			int digito = random.nextInt(10);
			numeroCuentaBanco.append(digito);
		}
		return numeroCuentaBanco.toString();
	}

//	public double getSaldoCC() {
//		System.out.printf("Saldo CC: %.2f\n", saldoCC);
//		System.out.println();
//		return saldoCC;
//	}
//
//	public double getSaldoCA() {
//		System.out.printf("Saldo CA: %.2f", saldoCA);
//		System.out.println();
//		return getSaldoCA();
//	}
	public Double getSaldoCC() {
		return saldoCC;
	}
	
	public Double getSaldoCA() {
		return saldoCA;
	}

	// Contrusctor de class main
	public BankAccount(double saldoInicialCC, double saldoInicialCA) {
		saldoCC = saldoInicialCC;
		saldoCA = saldoInicialCA;
	}


	// DEPOSITOS
	public void depositarCC(double monto) {
		saldoCC += monto;
		System.out.println("Deposito en Cuenta Corriente: $" + monto);
	}

	public void depositarCA(double monto) {
		saldoCC += monto;
		System.out.println("Deposito en Cuenta Ahorros: $" + monto);
	}

	// RETIROS
	public void retirarCC(double monto) {
		if (monto <= saldoCC) {
			saldoCC -= monto;
			System.out.println("Retiro en Cuenta Corriente: $" + monto);
		} else {
			System.out.println("Fondos insuficientes en la cuenta corriente.");
		}
	}

	public void retirarCA(double monto) {
		if (monto <= saldoCC) {
			saldoCC -= monto;
			System.out.println("Retiro en Cuenta Ahorro: $" + monto);
		} else {
			System.out.println("Fondos insuficientes en la cuenta de ahorros.");
		}
	}

	// Ver TOTAL de dinero CC,CA
	public void verSaldoTotal() {
		System.out.println("Saldo en cuenta corriente: $" + saldoCC);
		System.out.println("Saldo en cuenta Ahorro: $" + saldoCA);
	}

	public static int getNroCuentasCreadas() {
		return nroCuentasCreadas;
	}

	
	
	

}
