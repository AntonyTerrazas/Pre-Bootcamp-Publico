package com.tony.cuentadebanco.main;

import com.tony.cuentadebanco.clases.BankAccount;

public class TestBankAccount {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		BankAccount usuario1 = new BankAccount();
		
		
		System.out.println("CUENTAS CREADAS:  " + BankAccount.getNroCuentasCreadas());		
		System.out.println("numero de cuenta del usuario1: " + usuario1.generarNuemroCuenta());
		;
		System.out.println("");
		
		//depositos
		BankAccount cuenta = new BankAccount(1000, 2000);

        cuenta.depositarCC(500);
        cuenta.depositarCA(1000);
        cuenta.retirarCC(200);
        cuenta.retirarCA(300);
        cuenta.verSaldoTotal();
        System.out.println("");
        
		

      
	}

}
