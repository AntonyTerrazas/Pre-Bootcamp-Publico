package com.codingdojo.cadenas.controllers;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Cadenas {
	
	@RequestMapping("/")
	public String raiz() {
		return "Bienvenido Cliente. ¿Como se siente?";
	}
	
	@GetMapping("/random")
	public String random() {
		return "Cadenas con Spring boot y enreutamiento!";
	}

}
