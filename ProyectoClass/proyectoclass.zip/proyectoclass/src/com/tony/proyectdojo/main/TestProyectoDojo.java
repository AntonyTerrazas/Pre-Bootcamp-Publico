package com.tony.proyectdojo.main;

import com.tony.proyectdojo.clases.ProyectoDojo;

public class TestProyectoDojo {

	public static void main(String[] args) {

		ProyectoDojo ventaropa = new ProyectoDojo("Tienda Tony");
		String proyect1 = ventaropa.getNombre();
		System.out.println("El Proyecto es para : " + proyect1);
		
		ProyectoDojo ventaRopa2 = new ProyectoDojo("Tienda Tony","Venta de Indumentaria");
		String ventaRopaNombre = ventaRopa2.getNombre();
		String ventaRopaDescripcion = ventaRopa2.getDescripcion();{
		System.out.println("PROYECTO- " + ventaRopaNombre+" : " + ventaRopaDescripcion);
		}
		
		
		ProyectoDojo ventaRopa3 = new ProyectoDojo();
		ventaRopa3.setNombre(proyect1);
		ventaRopa3.setDescripcion("Hola estoy vendiendo indumentaria");
		
		String tipoProyecto = ventaRopa3.elevatorPitch();
		System.out.println(tipoProyecto);
	}



}
