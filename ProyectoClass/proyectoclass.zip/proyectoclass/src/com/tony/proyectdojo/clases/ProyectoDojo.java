package com.tony.proyectdojo.clases;

public class ProyectoDojo {

	private String nombre;
	private String descripcion;
	
	public ProyectoDojo() {
		
	}
	
	public ProyectoDojo(String name) {
		nombre = name;
		
	}

	public ProyectoDojo(String name, String description) {
		nombre = name;
		this.descripcion = description ;		
	}
	
	public String elevatorPitch() {
        return "PROYECTO- " + this.nombre + " : " + this.descripcion;
    }

	
	//GETTERS AND SETTERS
	
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nom) {
        nombre = nom;
    }

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String desc) {
        descripcion = desc;
    }
	
	
	
	
}
