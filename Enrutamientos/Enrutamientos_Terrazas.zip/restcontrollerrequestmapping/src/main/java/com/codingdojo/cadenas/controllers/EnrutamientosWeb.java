package com.codingdojo.cadenas.controllers;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class EnrutamientosWeb {
	
	@RequestMapping("")
	public String raiz() {
		return "BIENVENIDO";
	}
	
	@GetMapping("/coding")
	public String Coding() {
		System.out.println("¡Hola Coding Dojo!");
		return "¡Hola Coding Dojo!";
	}
	
	@GetMapping("/coding/python")
	public String Python() {
		return "\"¡Python/Django fue increíble!";
	}
	@GetMapping("/coding/java")
	public String Java() {
		return "¡Java/Spring es mejor!!";
	}
	//DOJO CONTROLLER"
	
	@GetMapping("/dojo")
	public String dojoIncreible() {
		return "El Dojo es Increible!";
	}
	
	@GetMapping("/burbank-dojo")
	public String Burbank() {
		return " El Dojo Burbank está localizado al sur de California ";
	}
	
	@GetMapping("/san-jose")
	public String sanJose() {
		return " El Dojo SJ es el cuartel general";
	}
	
	
	
}
