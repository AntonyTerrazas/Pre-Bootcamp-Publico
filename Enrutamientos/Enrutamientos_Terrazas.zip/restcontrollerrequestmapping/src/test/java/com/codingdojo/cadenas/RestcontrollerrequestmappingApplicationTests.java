package com.codingdojo.cadenas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestcontrollerrequestmappingApplicationTests {

	@Test
	void contextLoads() {
	}

}
