package com.codingdojo.juegoninjagold;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Z5juegoninjagoldApplicationTests {

	@Test
	void contextLoads() {
	}

}
