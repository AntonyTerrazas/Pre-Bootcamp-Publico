package com.tony.maestroobjetos.clases;

public class Humano {

	private int fuerza = 3;
	private int inteligencia = 3;
	private int sigilo = 3;
	private int vida = 100;
;
	
	
	//GETERS & SETTERS:
	public int getFuerza() {
		return fuerza;
	}
	public void setFuerza(int fuerza) {
		this.fuerza = fuerza;
	}
	public int getInteligencia() {
		return inteligencia;
	}
	public void setInteligencia(int inteligencia) {
		this.inteligencia = inteligencia;
	}
	public int getSigilo() {
		return sigilo;
	}
	public void setSigilo(int sigilo) {
		this.sigilo = sigilo;
	}
	public int getVida() {
		return vida;
	}
	public void setVida(int vida) {
		this.vida = vida;
	}

	//-----------------
	public String ataque() {
		
		setVida(getVida() - fuerza );
		return "Se ah atacado. La vida sera: "+vida;
	}
	
	//CONSTRUCTOR 
	public Humano() {
		// TODO Auto-generated constructor stub
	}
	//----------HUMANOS
	
	public Humano(int vida, int fuerza) {
		this.vida = vida;
		this.fuerza = fuerza;
	}
	
	
	
	
	public void atacar(Humano objetivo) {
		int puntosDeAtaque = this.fuerza;
		System.out.println("¡Un humano esta atacando!");
	
		objetivo.recibirAtaque(puntosDeAtaque);
	}
	
	public void recibirAtaque(int puntosDeAtaque) {
		if (puntosDeAtaque > 0) {
			this.vida -= puntosDeAtaque;
			System.out.println("El Humano recibio " +puntosDeAtaque+" puntos de daño");
		}else {
			System.out.println("El ataque no tiene efecto");
		}
	}
	
	
	
	
}








