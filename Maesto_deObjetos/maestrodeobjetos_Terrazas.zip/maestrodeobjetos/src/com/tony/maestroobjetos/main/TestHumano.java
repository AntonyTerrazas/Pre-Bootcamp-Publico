package com.tony.maestroobjetos.main;

import com.tony.maestroobjetos.clases.Humano;

public class TestHumano {

	public static void main(String[] args) {

		Humano pepito = new Humano();
		System.out.println(pepito.ataque());
		System.out.println(pepito.getVida());
		
		Humano humano1 = new Humano(100,3);
		Humano humano2 = new Humano(100,3);
		
		System.out.println("Vida del humano 1: " + humano1.getVida());
		System.out.println("Vida del humano 2: " + humano2.getVida());
		System.out.println("Vida del pepito: " + pepito.getVida());
		
		System.out.println("");

		humano1.atacar(humano2);
			System.out.println("ahora tiene "+humano2.getVida()+" y el otro" + humano1.getVida());
			System.out.println("");
		humano1.atacar(pepito);
			System.out.println(" ahora tiene "+humano2.getVida()+" y el otro" + pepito.getVida());
			System.out.println("");
		humano2.atacar(humano1);
			System.out.println(" ahora tiene "+humano2.getVida()+" y el otro" + humano1.getVida());
			System.out.println("");
		humano1.atacar(humano2);
			System.out.println(" ahora tiene "+humano1.getVida()+" y el otro" + humano2.getVida());
			System.out.println("");

		System.out.println("Vida del humano 1: " + humano1.getVida());
		System.out.println("Vida del humano 2: " + humano2.getVida());
		System.out.println("Vida del pepito: " + pepito.getVida());

		
	}

}
