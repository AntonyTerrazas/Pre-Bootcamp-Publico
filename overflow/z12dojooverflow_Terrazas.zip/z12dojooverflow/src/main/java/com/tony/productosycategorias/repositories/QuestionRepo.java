package com.tony.productosycategorias.repositories;

import org.springframework.data.repository.CrudRepository;

import com.tony.productosycategorias.models.QuestionsModel;

public interface QuestionRepo extends CrudRepository<QuestionsModel, Long> {

}
