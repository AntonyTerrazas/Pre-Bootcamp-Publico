package com.tony.productosycategorias.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.tony.productosycategorias.models.AnswerModel;

@Repository
public interface AnswerRepo extends CrudRepository<AnswerModel, Long>{
	
	List<AnswerModel> findAllByQuestionId(Long questionId);
	
	

}
