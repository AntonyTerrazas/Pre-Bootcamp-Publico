package com.tony.productosycategorias;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Z12dojooverflowApplication {

	public static void main(String[] args) {
		SpringApplication.run(Z12dojooverflowApplication.class, args);
	}

}
