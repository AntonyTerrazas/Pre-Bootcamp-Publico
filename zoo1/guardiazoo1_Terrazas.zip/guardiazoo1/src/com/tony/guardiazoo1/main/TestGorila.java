package com.tony.guardiazoo1.main;

import com.tony.guardiazoo1.clases.Gorila;

public class TestGorila {

	public static void main(String[] args) {

		System.out.println("BIENVENIDO!!");
		
		Gorila sube = new Gorila();
		String objeto1 = sube.escalar();
		System.out.println(objeto1 +"hola" );
		
		Gorila monito = new Gorila();
		System.out.println( monito.comerBanana() );
		System.out.println(monito.escalar());
		System.out.println(monito.tirarCosas());
		System.out.println(monito.mostrarEnergia());
		
		
		
		
	}

}
