package com.tony.guardiazoo1.clases;
;

public class Gorila extends Mamifero{
	
	public String tirarCosas() {
		
		setNivelEnergia(getNivelEnergia() - 5 );
		return "El gorila ha lanzado algo y disminuyo a " + nivelEnergia + " su energia.en (-5)";		
	}
	
public String comerBanana() {
		
		setNivelEnergia(getNivelEnergia() + 10 );
		return "El gorila ha comido una banana, ¡Le Gustó!. Aumento su energia  +10 . :: " + nivelEnergia ;		
	}

public String escalar() {
	
	setNivelEnergia(getNivelEnergia() - 10 );
	return "El gorila ha trepado a la cima de un árbol. Su energia se reducira -10.::  " + nivelEnergia ;		
}

	
}
