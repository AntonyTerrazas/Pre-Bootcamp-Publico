package com.tony.guardiazoo1.clases;

public class Mamifero {

	protected int nivelEnergia = 100;

	public int getNivelEnergia() {
		return nivelEnergia;
	}

	public void setNivelEnergia(int nivelEnergia) {
		this.nivelEnergia = nivelEnergia;
	}
	
	public int mostrarEnergia() {
		System.out.println("Su energia es: " + nivelEnergia);
		return nivelEnergia;
		
	}
	
	
}


