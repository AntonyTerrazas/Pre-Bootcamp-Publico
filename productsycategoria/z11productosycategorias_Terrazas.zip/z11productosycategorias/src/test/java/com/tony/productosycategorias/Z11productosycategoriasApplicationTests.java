package com.tony.productosycategorias;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Z11productosycategoriasApplicationTests {

	@Test
	void contextLoads() {
	}

}
