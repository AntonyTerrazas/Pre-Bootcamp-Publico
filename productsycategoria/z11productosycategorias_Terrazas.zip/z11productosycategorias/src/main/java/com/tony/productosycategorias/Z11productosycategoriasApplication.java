package com.tony.productosycategorias;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Z11productosycategoriasApplication {

	public static void main(String[] args) {
		SpringApplication.run(Z11productosycategoriasApplication.class, args);
	}

}
