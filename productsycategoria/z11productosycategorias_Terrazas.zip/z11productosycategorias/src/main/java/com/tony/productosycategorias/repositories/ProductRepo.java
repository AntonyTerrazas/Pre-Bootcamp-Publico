package com.tony.productosycategorias.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.tony.productosycategorias.models.CategoryModel;
import com.tony.productosycategorias.models.ProductModel;


public interface ProductRepo extends CrudRepository<ProductModel, Long>{
	
List<ProductModel> findAll();

//Lista para categoria: enviado a service de categoria
List<ProductModel>findByCategoriesNotContains(CategoryModel categoria);
}
